# Neural Entropy Modelling (NEM)

> **AI-Driven Cryptographic Framework for Industrial Cybersecurity using Solar Irradiance**
> M.Sc. Graduation Project — King Fahd University of Petroleum and Minerals (KFUPM), 2026

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![NIST SP 800-90B](https://img.shields.io/badge/NIST-SP%20800--90B-green.svg)](https://csrc.nist.gov/pubs/sp/800/90/b/final)
[![FIPS 197](https://img.shields.io/badge/FIPS-197%20AES--256-green.svg)](https://csrc.nist.gov/pubs/fips/197/final)

---

## 📌 Overview

**Neural Entropy Modelling (NEM)** is a lightweight, software-defined framework
that extracts cryptographic-grade randomness from ambient solar irradiance data
on commodity edge hardware (Raspberry Pi 5). It addresses **entropy starvation**
in Industrial Control Systems (ICS) deployed in renewable energy microgrids.

The framework uses a **deep LSTM autoencoder** (only 1,152 trainable parameters)
as a neural whitener, fuses its latent bitstream with CPU temporal jitter via
bitwise XOR, gates the result with the NIST SP 800-90B Most Common Value (MCV)
estimator, and conditions the entropy through **HKDF-SHA256** to produce a
FIPS 197-compliant **256-bit AES key**.

### Key Results

| Metric | Value |
|---|---|
| Min-entropy (H∞) | **0.9795 bits/bit** |
| NIST SP 800-22 pass rate (final key) | **100% (7/7)** |
| LSTM validation MSE | 0.0086 (no overfitting) |
| Trainable parameters | 1,152 |
| Target platform | Raspberry Pi 5 (8 GB) |
| AES-256-GCM round-trip | ✅ Successful |

---

## 📁 Repository Structure

```
NEM/
├── README.md                          ← you are here
├── requirements.txt                   ← Python dependencies
├── LICENSE                            ← MIT license
├── .gitignore
│
├── src/
│   ├── NEM_Final.py                   ← Streamlit live dashboard
│   └── numpy_lstm.py                  ← NumPy-only LSTM (TF fallback)
│
├── notebooks/
│   └── Solar_Entropy_Pipeline.ipynb   ← end-to-end Jupyter pipeline
│
└── data/
    ├── README.md
    └── solar_sample_10k.csv           ← 10 000 samples from Calgary PV site
```

---

## 🚀 Quick Start

### 1. Clone the repository

```bash
git clone https://github.com/<your-username>/NEM.git
cd NEM
```

### 2. Set up a virtual environment

```bash
python3 -m venv venv
source venv/bin/activate          # macOS / Linux
# venv\Scripts\activate           # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the Jupyter notebook (full pipeline)

```bash
jupyter notebook notebooks/Solar_Entropy_Pipeline.ipynb
```

Then **Run All Cells**. The notebook executes the full pipeline from solar
telemetry → LSTM whitening → XOR fusion → HKDF → AES-256 key, and produces
all figures and metrics reported in the graduation report.

### 5. Run the live Streamlit dashboard (optional)

```bash
streamlit run src/NEM_Final.py
```

The dashboard exposes a real-time view of the pipeline with NIST p-values,
min-entropy tracking, and a generated 256-bit AES key. To connect a real
BH1750 sensor over I²C, edit `PORT` at the top of `NEM_Final.py`.

---

## 🏗️ Architecture

```
   Solar Panel + BH1750 sensor (I²C @ 400 kHz)
                │
                ▼
   ┌──────────────────────────┐
   │ 1. Detrend & Normalize   │  ε(t) = S(t) − T(t), scaled to [−1, 1]
   └──────────────┬───────────┘
                  ▼
   ┌──────────────────────────┐
   │ 2. LSTM Autoencoder      │  W=64 → latent Z_t (16-dim) → bits
   │    (1,152 parameters)    │
   └──────────────┬───────────┘
                  ▼
   ┌──────────────────────────┐
   │ 3. Hardware Temporal     │  Δt from CPU interrupts
   │    Jitter + von Neumann  │  → debiased J_t
   └──────────────┬───────────┘
                  ▼
   ┌──────────────────────────┐
   │ 4. XOR Fusion            │  S_raw = Z_t ⊕ J_t
   └──────────────┬───────────┘
                  ▼
   ┌──────────────────────────┐
   │ 5. MCV Gate (NIST 800-90B)│  H∞ ≥ 0.8  ✓
   └──────────────┬───────────┘
                  ▼
   ┌──────────────────────────┐
   │ 6. HKDF-SHA256           │  PRK = HMAC(salt, S_raw)
   │    (RFC 5869)            │  K_AES = HMAC(PRK, info)
   └──────────────┬───────────┘
                  ▼
            256-bit AES key
```

---

## 🔧 Hardware (optional — for online mode)

| Component | Specification |
|---|---|
| Edge gateway | Raspberry Pi 5 Model B (8 GB) |
| MCU | Arduino Uno R3 |
| Light sensor | BH1750 GY-302 (16-bit, 1–65 535 lux) |
| Solar panel | 6 V / 1 W (drives the sensor) |
| Bus | I²C @ 400 kHz |
| Sampling rate | 1 sample / 60 s |

The framework also runs in **offline mode** (no hardware) by reading from
`data/solar_sample_10k.csv` — all results in the report were produced this way
for reproducibility.

---

## 📊 Reproducing the Results

All results are reproducible from the notebook with seed `42`:

```python
SEED = 42
WINDOW = 64
LATENT = 16
EPOCHS = 10
LR = 1e-3
```

Expected outputs:

- **LSTM training MSE:** 0.4435 (epoch 1) → 0.0098 (epoch 10)
- **Validation MSE:** 0.0086
- **Bit-balance (1-ratio):** 0.4986
- **Min-entropy (MCV):** 0.9795 bits/bit
- **NIST SP 800-22 pass rate on final key:** 100% (7/7)
- **AES-256-GCM round-trip:** successful on test command `"set valve to 30% open"`

---

## 📚 Citation

```bibtex
@mastersthesis{alhusaini2026nem,
  title  = {AI-Based Entropy Modelling of Solar Irradiance for Renewable
            and Scalable Cryptographic Security in Industrial Systems},
  author = {Alhusaini, Norah A.},
  school = {King Fahd University of Petroleum and Minerals},
  year   = {2026},
  type   = {M.Sc. Graduation Project},
  address= {Dhahran, Saudi Arabia}
}

@article{helmy2026nem,
  title   = {AI-Driven Neural Entropy Modelling for Industrial Cybersecurity:
             A Solar Irradiance Based Cryptographic Framework},
  author  = {Helmy, Tarek and Alhusaini, Norah and Redah, Moussa},
  journal = {IEEE Access},
  year    = {2026},
  note    = {Under review}
}
```

---

## 👥 Authors & Acknowledgements

**Author:** Norah A. Alhusaini — M.Sc. Artificial Intelligence, KFUPM
**Advisor:** Prof. Tarek Ahmed Helmy El-Bassuny — KFUPM
**Industry Mentor:** Eng. Ahmed Motmi — SABIC

This work was supported by:
- King Fahd University of Petroleum and Minerals (KFUPM)
- Interdisciplinary Research Center for Intelligent Secure Systems (IRC-ISS)
- National Cybersecurity Authority (NCA), Saudi Arabia

---

## 📜 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for
details. Academic use, modification, and distribution are permitted with proper
attribution.

---

## 🔗 Related Standards

- [NIST SP 800-90B — Recommendation for Entropy Sources](https://csrc.nist.gov/pubs/sp/800/90/b/final)
- [NIST SP 800-22 — Statistical Test Suite for RNGs](https://csrc.nist.gov/pubs/sp/800/22/r1/upd1/final)
- [FIPS PUB 197 — Advanced Encryption Standard (AES)](https://csrc.nist.gov/pubs/fips/197/final)
- [RFC 5869 — HMAC-based Extract-and-Expand Key Derivation Function (HKDF)](https://datatracker.ietf.org/doc/html/rfc5869)
